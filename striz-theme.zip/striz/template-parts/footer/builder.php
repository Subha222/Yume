<div class="wrap">
    <div class="container">
        <?php xstriz_render_footer(); ?>
    </div>
</div>